advancement revoke @s only dragonlight:trade/cyan_candle
tag @s add dl_cyan_candle
schedule function dragonlight:collect/cyan_candle 1s replace
