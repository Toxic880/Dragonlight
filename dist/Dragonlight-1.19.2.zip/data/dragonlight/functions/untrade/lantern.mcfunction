advancement revoke @s only dragonlight:trade/lantern
tag @s add dl_lantern
schedule function dragonlight:collect/lantern 1s replace
