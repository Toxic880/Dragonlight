advancement revoke @s only dragonlight:trade/soul_campfire
tag @s add dl_soul_campfire
schedule function dragonlight:collect/soul_campfire 1s replace
