advancement revoke @s only dragonlight:trade/red_candle
tag @s add dl_red_candle
schedule function dragonlight:collect/red_candle 1s replace
