execute as @a[tag=dl_yellow_candle] run clear @s minecraft:yellow_candle 1
tag @a remove dl_yellow_candle
