advancement revoke @s only dragonlight:trade/orange_candle
tag @s add dl_orange_candle
schedule function dragonlight:collect/orange_candle 1s replace
