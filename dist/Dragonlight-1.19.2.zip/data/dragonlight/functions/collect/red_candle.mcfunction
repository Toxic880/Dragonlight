execute as @a[tag=dl_red_candle] run clear @s minecraft:red_candle 1
tag @a remove dl_red_candle
