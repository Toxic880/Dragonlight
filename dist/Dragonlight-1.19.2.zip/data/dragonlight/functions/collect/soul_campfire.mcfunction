execute as @a[tag=dl_soul_campfire] run clear @s minecraft:soul_campfire 1
tag @a remove dl_soul_campfire
