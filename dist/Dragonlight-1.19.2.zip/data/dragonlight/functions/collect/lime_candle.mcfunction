execute as @a[tag=dl_lime_candle] run clear @s minecraft:lime_candle 1
tag @a remove dl_lime_candle
