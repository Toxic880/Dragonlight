execute as @a[tag=dl_white_candle] run clear @s minecraft:white_candle 1
tag @a remove dl_white_candle
