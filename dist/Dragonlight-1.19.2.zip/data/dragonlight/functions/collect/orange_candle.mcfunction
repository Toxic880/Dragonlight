execute as @a[tag=dl_orange_candle] run clear @s minecraft:orange_candle 1
tag @a remove dl_orange_candle
