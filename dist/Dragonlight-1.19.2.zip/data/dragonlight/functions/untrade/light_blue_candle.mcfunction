advancement revoke @s only dragonlight:trade/light_blue_candle
tag @s add dl_light_blue_candle
schedule function dragonlight:collect/light_blue_candle 1s replace
