execute as @a[tag=dl_blue_candle] run clear @s minecraft:blue_candle 1
tag @a remove dl_blue_candle
