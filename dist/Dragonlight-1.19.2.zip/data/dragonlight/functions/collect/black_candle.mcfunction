execute as @a[tag=dl_black_candle] run clear @s minecraft:black_candle 1
tag @a remove dl_black_candle
