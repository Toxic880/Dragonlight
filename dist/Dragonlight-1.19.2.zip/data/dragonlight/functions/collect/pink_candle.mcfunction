execute as @a[tag=dl_pink_candle] run clear @s minecraft:pink_candle 1
tag @a remove dl_pink_candle
