execute as @a[tag=dl_torch] run clear @s minecraft:torch 1
tag @a remove dl_torch
