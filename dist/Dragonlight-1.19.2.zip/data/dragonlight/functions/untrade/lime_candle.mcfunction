advancement revoke @s only dragonlight:trade/lime_candle
tag @s add dl_lime_candle
schedule function dragonlight:collect/lime_candle 1s replace
