execute as @a[tag=dl_campfire] run clear @s minecraft:campfire 1
tag @a remove dl_campfire
