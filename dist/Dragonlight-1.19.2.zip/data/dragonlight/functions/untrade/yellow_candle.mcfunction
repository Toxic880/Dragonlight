advancement revoke @s only dragonlight:trade/yellow_candle
tag @s add dl_yellow_candle
schedule function dragonlight:collect/yellow_candle 1s replace
