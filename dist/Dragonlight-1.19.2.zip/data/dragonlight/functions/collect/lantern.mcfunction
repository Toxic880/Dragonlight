execute as @a[tag=dl_lantern] run clear @s minecraft:lantern 1
tag @a remove dl_lantern
