advancement revoke @s only dragonlight:trade/copper_lantern
tag @s add dl_copper_lantern
schedule function dragonlight:collect/copper_lantern 1s replace
