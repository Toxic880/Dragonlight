execute as @a[tag=dl_cyan_candle] run clear @s minecraft:cyan_candle 1
tag @a remove dl_cyan_candle
