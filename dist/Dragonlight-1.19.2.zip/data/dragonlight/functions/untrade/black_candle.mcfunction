advancement revoke @s only dragonlight:trade/black_candle
tag @s add dl_black_candle
schedule function dragonlight:collect/black_candle 1s replace
