execute as @a[tag=dl_copper_lantern] run clear @s minecraft:copper_lantern 1
tag @a remove dl_copper_lantern
