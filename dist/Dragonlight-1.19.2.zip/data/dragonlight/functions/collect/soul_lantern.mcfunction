execute as @a[tag=dl_soul_lantern] run clear @s minecraft:soul_lantern 1
tag @a remove dl_soul_lantern
