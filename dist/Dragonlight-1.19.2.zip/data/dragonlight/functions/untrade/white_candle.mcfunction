advancement revoke @s only dragonlight:trade/white_candle
tag @s add dl_white_candle
schedule function dragonlight:collect/white_candle 1s replace
