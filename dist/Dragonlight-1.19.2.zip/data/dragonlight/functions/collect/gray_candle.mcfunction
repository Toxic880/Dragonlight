execute as @a[tag=dl_gray_candle] run clear @s minecraft:gray_candle 1
tag @a remove dl_gray_candle
