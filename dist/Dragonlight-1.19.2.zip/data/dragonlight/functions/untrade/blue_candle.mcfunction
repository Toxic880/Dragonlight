advancement revoke @s only dragonlight:trade/blue_candle
tag @s add dl_blue_candle
schedule function dragonlight:collect/blue_candle 1s replace
