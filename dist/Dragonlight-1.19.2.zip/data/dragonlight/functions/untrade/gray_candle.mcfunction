advancement revoke @s only dragonlight:trade/gray_candle
tag @s add dl_gray_candle
schedule function dragonlight:collect/gray_candle 1s replace
