advancement revoke @s only dragonlight:trade/light_gray_candle
tag @s add dl_light_gray_candle
schedule function dragonlight:collect/light_gray_candle 1s replace
