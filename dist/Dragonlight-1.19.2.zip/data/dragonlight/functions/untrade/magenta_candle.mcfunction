advancement revoke @s only dragonlight:trade/magenta_candle
tag @s add dl_magenta_candle
schedule function dragonlight:collect/magenta_candle 1s replace
