advancement revoke @s only dragonlight:trade/candle
tag @s add dl_candle
schedule function dragonlight:collect/candle 1s replace
