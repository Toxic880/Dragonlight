advancement revoke @s only dragonlight:trade/copper_torch
tag @s add dl_copper_torch
schedule function dragonlight:collect/copper_torch 1s replace
