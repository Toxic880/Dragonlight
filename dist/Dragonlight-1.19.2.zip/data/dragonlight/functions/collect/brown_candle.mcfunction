execute as @a[tag=dl_brown_candle] run clear @s minecraft:brown_candle 1
tag @a remove dl_brown_candle
