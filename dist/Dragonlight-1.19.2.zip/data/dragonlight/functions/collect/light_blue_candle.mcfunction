execute as @a[tag=dl_light_blue_candle] run clear @s minecraft:light_blue_candle 1
tag @a remove dl_light_blue_candle
