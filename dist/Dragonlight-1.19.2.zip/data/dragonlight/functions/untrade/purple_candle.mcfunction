advancement revoke @s only dragonlight:trade/purple_candle
tag @s add dl_purple_candle
schedule function dragonlight:collect/purple_candle 1s replace
