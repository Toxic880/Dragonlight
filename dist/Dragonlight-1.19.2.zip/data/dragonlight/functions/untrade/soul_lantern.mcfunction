advancement revoke @s only dragonlight:trade/soul_lantern
tag @s add dl_soul_lantern
schedule function dragonlight:collect/soul_lantern 1s replace
