execute as @a[tag=dl_candle] run clear @s minecraft:candle 1
tag @a remove dl_candle
