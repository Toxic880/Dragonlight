# Un-learn the locked recipes.
recipe take @a minecraft:campfire
recipe take @a minecraft:lantern
recipe take @a minecraft:soul_campfire
recipe take @a minecraft:soul_lantern
recipe take @a minecraft:soul_torch
recipe take @a minecraft:torch
schedule function dragonlight:setup 5s replace
