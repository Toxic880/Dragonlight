execute as @a[tag=dl_magenta_candle] run clear @s minecraft:magenta_candle 1
tag @a remove dl_magenta_candle
