advancement revoke @s only dragonlight:trade/torch
tag @s add dl_torch
schedule function dragonlight:collect/torch 1s replace
