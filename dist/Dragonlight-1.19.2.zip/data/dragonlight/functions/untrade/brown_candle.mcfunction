advancement revoke @s only dragonlight:trade/brown_candle
tag @s add dl_brown_candle
schedule function dragonlight:collect/brown_candle 1s replace
