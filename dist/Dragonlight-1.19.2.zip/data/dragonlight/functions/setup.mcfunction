# Un-learn the locked recipes.
recipe take @a minecraft:black_candle
recipe take @a minecraft:blue_candle
recipe take @a minecraft:brown_candle
recipe take @a minecraft:campfire
recipe take @a minecraft:candle
recipe take @a minecraft:cyan_candle
recipe take @a minecraft:gray_candle
recipe take @a minecraft:green_candle
recipe take @a minecraft:lantern
recipe take @a minecraft:light_blue_candle
recipe take @a minecraft:light_gray_candle
recipe take @a minecraft:lime_candle
recipe take @a minecraft:magenta_candle
recipe take @a minecraft:orange_candle
recipe take @a minecraft:pink_candle
recipe take @a minecraft:purple_candle
recipe take @a minecraft:red_candle
recipe take @a minecraft:soul_campfire
recipe take @a minecraft:soul_lantern
recipe take @a minecraft:soul_torch
recipe take @a minecraft:torch
recipe take @a minecraft:white_candle
recipe take @a minecraft:yellow_candle
schedule function dragonlight:setup 5s replace
