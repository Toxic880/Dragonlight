advancement revoke @s only dragonlight:trade/campfire
tag @s add dl_campfire
schedule function dragonlight:collect/campfire 1s replace
