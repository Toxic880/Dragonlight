advancement revoke @s only dragonlight:trade/green_candle
tag @s add dl_green_candle
schedule function dragonlight:collect/green_candle 1s replace
