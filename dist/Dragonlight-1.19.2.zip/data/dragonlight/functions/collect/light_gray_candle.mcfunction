execute as @a[tag=dl_light_gray_candle] run clear @s minecraft:light_gray_candle 1
tag @a remove dl_light_gray_candle
