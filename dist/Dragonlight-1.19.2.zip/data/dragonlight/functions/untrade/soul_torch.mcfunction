advancement revoke @s only dragonlight:trade/soul_torch
tag @s add dl_soul_torch
schedule function dragonlight:collect/soul_torch 1s replace
