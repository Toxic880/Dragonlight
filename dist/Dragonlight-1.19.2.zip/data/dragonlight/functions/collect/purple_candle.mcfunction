execute as @a[tag=dl_purple_candle] run clear @s minecraft:purple_candle 1
tag @a remove dl_purple_candle
