advancement revoke @s only dragonlight:trade/pink_candle
tag @s add dl_pink_candle
schedule function dragonlight:collect/pink_candle 1s replace
