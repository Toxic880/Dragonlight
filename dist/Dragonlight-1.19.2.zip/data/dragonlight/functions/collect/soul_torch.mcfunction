execute as @a[tag=dl_soul_torch] run clear @s minecraft:soul_torch 1
tag @a remove dl_soul_torch
