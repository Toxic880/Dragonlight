execute as @a[tag=dl_green_candle] run clear @s minecraft:green_candle 1
tag @a remove dl_green_candle
