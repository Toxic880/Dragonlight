execute as @a[tag=dl_copper_torch] run clear @s minecraft:copper_torch 1
tag @a remove dl_copper_torch
